CREATE TABLE [metadata].[processing_log] (

	[pipeline_run_id] varchar(225) NULL, 
	[table_processed] varchar(225) NULL, 
	[rows_processed] int NULL, 
	[latest_processed_pickup] datetime2(6) NULL, 
	[processed_datetime] datetime2(6) NULL
);