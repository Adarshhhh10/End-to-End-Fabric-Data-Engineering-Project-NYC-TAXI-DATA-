CREATE PROCEDURE metadata.insert_staging_metadata
    @pipeline_run_id varchar(225),
    @table_name VARCHAR(225),
    @processed_date DATETIME2
as
    insert into metadata.processing_log(pipeline_run_id, table_processed, rows_processed, latest_processed_pickup, processed_datetime)
    SELECT
        @pipeline_run_id as pipeline_id,
        @table_name as table_processed,
        count(*) as rows_processed,
        max(tpep_pickup_datetime) as latest_processed_pickup,
        @processed_date as processed_datetime
    from stg.nyctaxi_yellow;